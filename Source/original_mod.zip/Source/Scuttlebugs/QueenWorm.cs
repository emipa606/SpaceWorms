﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Verse;
using Verse.AI.Group;

namespace Scuttlebugs
{
    public class QueenWorm : ThingWithComps
    {

    }

}
