﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scuttlebugs
{
    public class Class1
    {
    }
}
